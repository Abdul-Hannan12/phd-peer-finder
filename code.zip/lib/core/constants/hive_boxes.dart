import 'package:hive/hive.dart';

const String userBoxName = 'userBox';

late Box userBox;
