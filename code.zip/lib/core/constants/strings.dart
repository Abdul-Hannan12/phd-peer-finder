const String dynamicAssets = "assets/dynamic_assets";
const String staticAssets = "assets/static_assets";
const String logoIconsAssets = "assets/logo_icons";
const String montserrat = "Montserrat";
