class LiveChannel {
  String? imgUrl;
  String? username;

  LiveChannel({
    this.imgUrl,
    this.username,
  });
}
