class Conference {
  String? imgUrl;
  String? username;

  Conference({
    this.imgUrl,
    this.username,
  });
}
