class StudyPartner {
  String? imgUrl;
  String? username;
  bool? online;

  StudyPartner({this.imgUrl, this.username, this.online = false});
}
