import 'package:phd_peer/core/others/base_view_model.dart';

class HomeViewModel extends BaseViewModel {}
